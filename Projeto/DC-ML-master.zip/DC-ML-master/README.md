# DC-ML

## About
This repo contains codes for the DC-ML Algorithm.

### Prerequisites
The following pakages are needed.
- sklearn
- statistics
- pandas
- matplotlib
- numpy
- openpyxl
- sqlalchemy
- patsy
